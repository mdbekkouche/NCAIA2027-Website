# NCAIA 2027 Author Kit

