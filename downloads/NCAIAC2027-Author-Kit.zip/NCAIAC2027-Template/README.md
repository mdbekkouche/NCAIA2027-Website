# NCAIAC 2027 Author Kit

